# Speech-to-Text
Flask application that takes speech as input and returns text as output using PYTHON, HTML & FLASK
